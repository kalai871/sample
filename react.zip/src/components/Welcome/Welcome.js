import { render } from '@testing-library/react';
import React, { useState } from 'react';
import { Form, Button, Row ,Col} from 'react-bootstrap'; 
const Welcome = (props) => {
   

  const depositRedirect = (event) => {
    event.preventDefault();
    props.history.push({
      pathname: '/profile/{id}'
    })
  }
render(
  <div>
    Your amount has been deposited successfully!
    <Button variant="primary" type="submit" onClick={depositRedirect}>
          Close
        </Button>
    </div>

)
 }
export default Welcome;