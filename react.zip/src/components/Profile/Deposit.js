import React, { useState, useEffect } from 'react';
import { Form, Button, Row ,Col} from 'react-bootstrap';
import classes from './Profile.css';
import axios from 'axios';
import UpdateProfile from './UpdateProfile';

const Deposit = (props) => {
    const [state, setState] = useState({
        
      });
    const handleOnSubmit = (event) => {
        event.preventDefault();
            props.modalStatus(event.target.name)
      };

      const depositRedirect = (event) => {
        event.preventDefault();
        props.history.push({
          pathname: '/welcome'
        })
      }
      const logoutRedirect = (event) => {
        event.preventDefault();
        props.history.push({
          pathname: '/logout'
        })
      }
    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setState((prevState) => ({
          ...prevState,
          [name]: value
        }));
      };
    
    return(
        <div>
            <h1>Deposit</h1>
            <Form className="register-form">    
    <Row>
    <Form.Group controlId="account" as={Col}>
            <Form.Label>Account Type</Form.Label>
            <Form.Control  as="select"
              placeholder="account type"
              name="account"  required
              >
                <option>Salary</option> 
              <option>Savings</option> 
              </Form.Control>
                <Form.Control.Feedback type="invalid">
                  Enter the Account Type
                </Form.Control.Feedback> 
                </Form.Group>
                <Form.Group controlId="depositamount" as={Col}>
            <Form.Label>Deposite Amount</Form.Label>
            <Form.Control
              type="number"
              placeholder="Enter Deposite Amount"
              name="depositamount"  required
              />
                <Form.Control.Feedback type="invalid">
                  Enter the Deposite Amount
                </Form.Control.Feedback> 
                </Form.Group>
        </Row>
       
  
        <Button variant="primary" type="submit" className="previous" onClick={depositRedirect}>
          Deposit
        </Button>
       
        <Button variant="primary" type="submit" className="next" onClick={logoutRedirect}>
         Available Balance
        </Button>
        </Form>
        </div>
        ) 
}

export default Deposit;