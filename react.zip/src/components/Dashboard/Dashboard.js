import React, { useState } from 'react';
import { Form, Button, Row ,Col} from 'react-bootstrap';
import EducationLoan from './EducationLoan';
import HomeLoan from './HomeLoan';
import Modal from 'react-modal';
import moment from 'moment';

const Dashboard = (props) => {
    const [state, setState] = useState({
        username: '',
        email: '',
        city: '',
        phone: ''
      });
      const [showLoanType,setShowLoanType] = useState({
        showEduLoan : false,
        showHomeLoan : false
      });

      const dateFormat = 'YYYY-MM-DD';
      const dateRange = moment(new Date()).format(dateFormat);

      const [modalIsOpen,setModalIsOpen] = useState(false);
      
      const [loanType, setLoanType] = useState(["Select" ,"Education Loan" , "Home loan"]);


      const LoanType = loanType.map(LoanType => LoanType)

        const handleLoanTypeChange = (e) => {
           console.log(e.target.value);
             const {value } = e.target;

             switch (value){
              case ("0"):
                setShowLoanType({
                  showHomeLoan : false,
                  showEduLoan : false
                 })  
              break;
              case ("1"):
                  setShowLoanType({
                    showHomeLoan : false,
                    showEduLoan : true
                   })  
              break;
              case ("2"):
                setShowLoanType({
                  showHomeLoan : true,
                  showEduLoan : false
                 }) 
              default:
              return null; 
               }
        };

        const handleOnSubmit = (event) => {
        event.preventDefault();
        props.history.push({
          pathname: '/dashboard',
          state
        });
      };
    
      const handleInputChange = (event) => {
        const { name, value } = event.target;
        setState((prevState) => ({
          ...prevState,
          [name]: value
        }));
      };

      const profileRedirect = (event) => {
        event.preventDefault();
        props.history.push({
          pathname: '/profile/{id}'
        })
      }

      const openModal = () => {
          setModalIsOpen(true);
      }
    
      const { showEduLoan , showHomeLoan} = showLoanType;


    return(
        <div>
            <h1>Apply Loan</h1>
            <Button variant="primary" type="submit" as={Col}  md="2"
        onClick={profileRedirect} >
          Deposit
        </Button>

            <Form className="register-form" onSubmit={handleOnSubmit}>    
        <Row>
        
        <Form.Group as={Col} controlId="loantype">
          <Form.Label>Loan Type</Form.Label>
          <Form.Control as="select"
            onChange={handleLoanTypeChange}
          >
          {
        LoanType.map((address, key) => <option value={key}>{address}</option>)
      }
      </Form.Control>
        </Form.Group>
        
        <Form.Group as={Col} controlId="loanamount">
          <Form.Label>Loan Amount</Form.Label>
          <Form.Control
            type="number"
            placeholder="Enter Loan Amount"
            name="loanamount"
          
          />
        </Form.Group>
        <Form.Group as={Col} controlId="loanapplydate">
            <Form.Label>Loan Apply Date</Form.Label>
            <Form.Control
              type="date" max={dateRange}
              placeholder="Enter Loan Apply Date"
              name="loanapplydate"
          
              /> 
                </Form.Group>
               
        <Form.Group controlId="rateofinterest" as={Col}>
          <Form.Label>Rate of interest</Form.Label>
          <Form.Control as="select"
            placeholder="Enter Rate of Interest"
            name="rateofinterest" required
           >
                <option>Select</option> 
              <option>5</option>
              <option>10</option>
              <option>15</option>
              <option>20</option>
           </Form.Control>
          
        </Form.Group>
        


        <Form.Group controlId="durationofloan" as={Col}>
          <Form.Label>Duration of Loan</Form.Label>
          <Form.Control
            type="number"
            placeholder="Enter Duration of Loan"
            name="durationofloan"
          
          />
        </Form.Group>
        
        </Row>
        
       
      
      </Form>
      
        {showEduLoan  && <EducationLoan modalStatus={openModal}/>}
        {showHomeLoan && <HomeLoan modalStatus={openModal}/>}
      
        <Modal isOpen={modalIsOpen} onRequestClose={() => setModalIsOpen(!modalIsOpen)}>
          <button onClick={() => setModalIsOpen(!modalIsOpen)} >close</button>
          <div>Your applicaltion has been processed successfully!!</div>
        </Modal>

        </div>
    )

    
}

export default Dashboard;