import React, { useState } from 'react';
import { Form, Button, Row ,Col} from 'react-bootstrap';
//import classes from './Dashboard.css';

const Homeloan = props => {
    const [state, setState] = useState({
        username: '',
        email: '',
        city: '',
        phone: ''
      });
    
      const handleOnSubmit = (event) => { 
        event.preventDefault();
        props.modalStatus(event.target.name)
      };
    
      const handleInputChange = (event) => {
        const { name, value } = event.target;
        setState((prevState) => ({
          ...prevState,
          [name]: value
        }));
      };
      
     
    
      return (
        <div>
      <h1>Home Loan</h1>
      <Form className="register-form" onSubmit={handleOnSubmit}>
          <Form.Row>
          <Form.Group as={Col} controlId="annualincome">
          <Form.Label>Annual Income</Form.Label>
          <Form.Control
            type="number"
            placeholder="Enter Annual Income"
            name="annualincome"
            onChange={handleInputChange}
          />
        </Form.Group>

        
        <Form.Group as={Col} controlId="companyname">
          <Form.Label>Company Name</Form.Label>
          <Form.Control
            type="text"  pattern="^[a-zA-Z]+(\s[a-zA-Z]+)?$"
            placeholder="Enter company Name"
            name="companyname"
            onChange={handleInputChange}
          />
        </Form.Group>
        
        <Form.Group as={Col} controlId="designation">
          <Form.Label>Designation</Form.Label>
          <Form.Control
            type="text"  pattern="^[a-zA-Z]+(\s[a-zA-Z]+)?$"
            placeholder="Enter Designation"
            name="designation"
            onChange={handleInputChange}
          />
        </Form.Group>
               
        <Form.Group as={Col} controlId="totalexp">
          <Form.Label>Total Experience</Form.Label>
          <Form.Control
            type="number"
            placeholder="Enter Total Experience"
            name="totalexp"
            onChange={handleInputChange}
          />
        </Form.Group>
        <Form.Group  as={Col} controlId="totalexpincc">
          <Form.Label>Total Exp in CC</Form.Label>
          <Form.Control
            type="number"
            placeholder="Enter Total Exp. in CC"
            name="totalexpincc"
            onChange={handleInputChange}
          />
        </Form.Group>
        
        </Form.Row>

      
        
        
        <Button variant="primary" type="submit">
          Apply Loan
        </Button>
      </Form>
    </div>
        
      );
}

export default Homeloan;