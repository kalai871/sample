import React from 'react';


import './hf.css';

const Footer = () => {
    return (
        <div className="Footer"> 
            <p>Bms</p>
        </div>
    )
}
export default Footer;