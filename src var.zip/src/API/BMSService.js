import axios from 'axios'

class BMSService{
   executeLoginService(val){
  let data={
     "username": val.username,
    "password": val.password
    }
     console.log(val)
       return axios.post('http://localhost:9037/api/login',data);
   }

   executeRegisterService(val){

    let data  = {
      "name" : val.name,
      "username" : val.username,
      "password" : val.password ,
      "depositamount" : val.depositamount,
     "address" :val.address,
     "country": val.country,
     "state" : val.state,
     "email" : val.email,
     "contactno" : val.contactno,
     "dob" : val.dob,
     "accounttype" : val.account,
     "branchname" : val.branchname,
     "prooftype": val.prooftype,
     "documentno": val.documentno
   
    }
        console.log(val)
       return axios.post('http://localhost:9037/api/register',data)

   }
    
   

   handleSuccess(data){
    console.log(data)
    return data;
  };

  handleError(data){
  console.log(data)
  };

}

export default new BMSService();