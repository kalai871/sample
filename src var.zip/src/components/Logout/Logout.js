import { render } from '@testing-library/react';
import React, { useState } from 'react';
import { Form, Button, Row ,Col} from 'react-bootstrap'; 
const Logout = (props) => {
  const loginRedirect = (event) => {
    event.preventDefault();
    props.history.push({
      pathname: '/'
    })
  }
render(
  <div>
    Your available balance is?
    <Button variant="primary" type="submit" onSubmit={loginRedirect}>
          Close
        </Button>
    </div>

)
 }
export default Logout;