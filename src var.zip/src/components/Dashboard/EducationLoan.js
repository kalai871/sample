import React, { useState } from 'react';
import { Form, Button, Row ,Col} from 'react-bootstrap';
//import classes from './Dashboard.css';


const EducationLoan = (props) => {
    const [state, setState] = useState({
        username: '',
        email: '',
        city: '',
        phone: ''
      });
    

        const handleOnSubmit = (event) => {
        event.preventDefault();
            props.modalStatus(event.target.name)
      };
    
      const handleInputChange = (event) => {
        const { name, value } = event.target;
        setState((prevState) => ({
          ...prevState,
          [name]: value
        }));
      };
    
    return(
        <div>
            <h1>Education Loan</h1>
            <Form className="register-form" onSubmit={handleOnSubmit}>    
    
        
        <Row>
        <Form.Group as={Col} controlId="coursefee">
          <Form.Label>Course Fee</Form.Label>
          <Form.Control
            type="number"
            placeholder="Enter Course fee"
            name="coursefee"
          />
        <Form.Control.Feedback type="invalid">
                Please enter valid data.
              </Form.Control.Feedback>
              </Form.Group>

        <Form.Group as={Col} controlId="course">
          <Form.Label>Course</Form.Label>
          <Form.Control
            type="text"  pattern="^[a-zA-Z]+(\s[a-zA-Z]+)?$"
            placeholder="Enter Course"
            name="course"
          />
             <Form.Control.Feedback type="invalid">
                Please enter valid data.
              </Form.Control.Feedback>
        </Form.Group>
        
        <Form.Group as={Col} controlId="fathername">
          <Form.Label>Father Name</Form.Label>
          <Form.Control
            type="text" pattern="^[a-zA-Z]+(\s[a-zA-Z]+)?$"
            placeholder="Enter Father Name"
            name="fathername"
        
          />
           <Form.Control.Feedback type="invalid">
                Please enter valid data.
              </Form.Control.Feedback>
        </Form.Group>

        <Form.Group as={Col} controlId="fatheroccupation">
          <Form.Label>Father Occupation</Form.Label>
          <Form.Control
            type="text"   pattern="^[a-zA-Z]+(\s[a-zA-Z]+)?$"
            placeholder="Enter Father Occupation"
            name="fatheroccupation"
         
          />
           <Form.Control.Feedback type="invalid">
                Please enter valid data.
              </Form.Control.Feedback>
        </Form.Group>

        <Form.Group as={Col} controlId="annualincome">
          <Form.Label>Annual Income</Form.Label>
          <Form.Control
            type="number"
            placeholder="Enter Annual Income"
            name="annualincome"
          
          />
           <Form.Control.Feedback type="invalid">
                Please enter valid data.
              </Form.Control.Feedback>
        </Form.Group>
        </Row>
        
        <Button variant="primary" type="submit" >
          Apply Loan
        </Button>
      </Form>

     

        </div>
    )
}

export default EducationLoan;