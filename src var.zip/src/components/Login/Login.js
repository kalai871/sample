import React, { useState } from 'react';
import { Form, Button, Row ,Col} from 'react-bootstrap'; 
import classes from './Login.css';
import BMSService from '../../API/BMSService';


const Login = props => {
  const [state, setState] = useState({
      username: '',
      password: ''
    });
  const [error,setError] = useState({})
    
   /* const handleSubmit = (event) => { 
      event.preventDefault();
      const { username, password } = state;
      if(username && password) {
        let val  = { 
          "username" : username,
          "password" : password 
        }
        BMSService.executeLoginService(val)
        .then(res=> handleSuccess(res))
        .catch(res=> handleError(res))
     }
  else{
    setError({sbm :"Invalid Username && Password"})
  }
  }  */
  const [validated, setValidated] = useState(true);

      const handleSubmit = (event) => {
        event.preventDefault();
        
    setValidated(true);
    props.history.push({
            pathname: '/dashboard'
      });
    };

  
const handleSuccess = (data) => {
  console.log(data) 
  props.history.push({
         pathname: '/dashboard'
    });
};

const handleError = (data) =>{
setError({sbm :"Invalid Username && Password"})
console.log(data)
};


 
    const registerRedirect = (event) => {
      event.preventDefault();
      props.history.push({
        pathname: '/register'
      });
    };
    const handleInputChange = (event) => {
      const { name, value } = event.target;
      let errValue = validate(name, value);
      if(errValue)
      setError(errValue) 

      setState((prevState) => ({
        ...prevState,  
        [name]: value
      }));
    };

      const  validate = (name, value) => {
        const err ={};
        switch (name) {
             
            case "username":
              if (!value || value.trim() === "") {
                err.username ="Username is Required";
              }else {
                err.username = "";
              }
              break;
            case "password":
              if (!value) {
                err.pwd = "Password is Required";
              }else {
                err.pwd = "";
              } 
              break; 

            }

            return err;
      };
      //const { errorsUser , errorsPwd} = error;
      const {username ,password} = state;

      
      return (
        <div>
      <h1>Login Form</h1>
      <form  className="register-form" >
<Row >
        <Col md="12" style={{marginBottom : "10px"}}>
            <label>Username:</label>
            <input style={{marginLeft:"15px"}}
              name="username"
              value ={username}
              onChange={handleInputChange}
              placeholder="Username" required maxLength ="10"
            />
              { error.username  &&  <p>
             <span className="text-danger">{error.username}</span> 
            </p> }
          </Col>
          <Col  md="12" style={{marginBottom : "20px"}}>
            <label>Password:</label>
            <input style={{marginLeft:"18px"}}
              type="Password"
              name="password"
              value ={password}
              onChange={handleInputChange}
              placeholder="Password"
            />
            {error.pwd  &&   <p>
             <span className="text-danger">{error.pwd}</span> 
            </p> }
               
          </Col>
          <br />
         
        <Button variant="primary" type="submit" as={Col} className="loginBtn" md="2" onClick={handleSubmit}>
          Login
        </Button>

        {error.sbm  &&   <p>
             <span className="text-danger">{error.sbm}</span> 
            </p> }
               
               
        <p variant="primary"  as={Col} className="signUp" md={{ span: 2, offset: 2 }} 
        onClick={registerRedirect} >
          New User Sign Up
        </p>

        {/* <Button variant="primary" type="submit" as={Col} className="loginBtn" md="2">
          Profile
        </Button> */}

        </Row>


        </form>
    </div>
        
      );
}

export default Login;